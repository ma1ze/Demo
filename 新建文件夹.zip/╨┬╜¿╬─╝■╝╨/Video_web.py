#!/usr/bin/env python

# WS server that sends camera streams to a web server using opencv


import asyncio
import websockets
import cv2
from aruco_image import *


async def time(websocket, path):
    while True:

        camera = True
        if camera == True:
            cap = cv2.VideoCapture(1)
        try:
            while (cap.isOpened()):
                img, frame = cap.read()
                result = aruco_image(frame)
                frame = cv2.resize(result.getImg(), (640, 480))
                encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 65]
                man = cv2.imencode('.jpg', frame, encode_param)[1]
                x=result.getX()
                y=result.getY()
                z=result.getZ()


                string_send = str(x)+"|"+str(y)+"|"+str(z)
                await websocket.send(string_send)
                # sender(man)
                await websocket.send(man.tobytes())

        except:

            pass


start_server = websockets.serve(time, "127.0.0.1", 9997)
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
