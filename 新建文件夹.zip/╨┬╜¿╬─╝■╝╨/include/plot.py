# 1.1280 720 120
# 2.640 360 330
# 3.1920 1080 60
import matplotlib.pyplot as plt


timeset = [0.0041,0.0016,0.0093]
timeCornor=[0.00024,0.00021,0.00025]
Time = [0,1,2]
plt.figure(1)
plt.plot(Time, timeset, label='center_x_pix', color='r')
plt.plot(Time, timeCornor, label='center_x_predicted_pix', color='g')
plt.show()